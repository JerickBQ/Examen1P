class capitan:Barco{
    public int horasexp {get;set;}
    public int sueldo {get;set;}
    public int Tsueldo {get;set;}
    public int bono {get;set;}
    public override datcapitan ();
     public capitan (int horasexp, int sueldo, int Tsueldo, int bono){
        this.horasexp=horasexp;
        this.sueldo=sueldo;
        this.Tsueldo=Tsueldo;
        this.bono=bono;

     }
     public void imprimircap(){
        Console.WriteLine(" La hora:"+horasexp);
        Console.WriteLine("El sueldo:"+ sueldo);
        Console.WriteLine("El sueldo total:"+Tsueldo);
        Console.WriteLine("El bono que recive:"+bono);

     }



}
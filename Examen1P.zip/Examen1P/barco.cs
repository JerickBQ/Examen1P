abstract class Barco{
    public string nombre{get;set;}
    public string capbar{get;set;}
    public string capcarg{get;set;}

    public override datosBar ();
public Barco (string nombre,string capbar,string capcarg){
    this.nombre=nombre;
    this.capbar=capbar;
    this.capcarg=capcarg;
    
}

    

public void imprimirBar(){
    Console.WriteLine("el nombre es"+ nombre);
    Console.WriteLine("La capacidad es"+ capbar);
    Console.WriteLine("La carga es "+ capcarg);

}
}
﻿internal class Program
{
    private static void Main(string[] args){
        Barco.imprimirBar();
        gps.imprimirgps();
        tripulante.imprimirtri();
        capitan.imprimircap();
        jflota.imprimirjf();



        Console.ReadKey();




    }




}
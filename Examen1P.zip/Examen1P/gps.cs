class gps:Barco{
    public string cordenadasX {get;set;}
    public string fecha {get;set;}

    
    public override datosLuyFe();


public gps (int cordenadasX, int fecha){
this.cordenadasX=cordenadasX;
this.fecha=fecha;

}
public void imprimirgps (){
    Console.WriteLine("Las coordenadas son "+cordenadasX);
    Console.WriteLine("La fecha es"+fecha);
}
}
class tripulante:Barco {
    public string name {get;set;}
    public int telefono {get;set;}
    public int cedula {get;set;}
    public int edad {get;set;}
    public int tiempoE {get;set;}
    public string sexo {get;set;}
    public string tba {get;set;}

    public override datripulantes ();
            public override tripulante (string name, int telefono, int cedula, int edad, int tiempoE, string sexo, string tba){
            this.name= name;
            this.telefono= telefono;
            this.cedula=cedula;
            this.edad= edad;
            this.tiempoE=tiempoE;
            this.sexo=sexo;
            this.tba=tba;

        }
        public void imprimirtri(){
            Console.WriteLine("El nombre del tripulante: "+ name);
            Console.WriteLine("El telefono: "+ telefono);
            Console.WriteLine("La cedula :"+cedula);
            Console.WriteLine("La edad: "+edad);
            Console.WriteLine("El tiempo: "+tiempoE);
            Console.WriteLine("El sexo: "+ sexo);
            Console.WriteLine("El barco: "+tba);

        }

}

class jflota:Barco{
  public int PagoPes {get;set;}
    public int PagoMaris {get;set;}
   public jflota (int PagoPes, int PagoMaris){
        this.PagoPes=PagoPes;
        this.PagoMaris=PagoMaris;
   }
public void imprimirjf (){
 Console.WriteLine(" El pago por el pescado:"+PagoPes);
Console.WriteLine("El pago por el :"+ PagoMaris);





}


}

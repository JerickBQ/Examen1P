class marinero:Barco{
    public int total {get;set;}
public marinero (int total){


this.marinero=marinero;
}
}
